UPDATE {{.prefix}}boards SET channel_id = '' WHERE is_template;
