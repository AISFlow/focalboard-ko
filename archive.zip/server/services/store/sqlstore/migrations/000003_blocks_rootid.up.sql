{{- /* addColumnIfNeeded tableName  columnName  datatype  constraint */ -}}
{{ addColumnIfNeeded "blocks" "root_id" "varchar(36)" ""}}