UPDATE {{.prefix}}categories SET collapsed = true;
