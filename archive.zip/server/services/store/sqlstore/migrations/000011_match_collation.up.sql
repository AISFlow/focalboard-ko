{{- /* All tables have collation fixed via code at startup so this migration is no longer needed. */ -}}
{{- /* See https://github.com/mattermost/focalboard/pull/4002                                     */ -}}

SELECT 1;



