{{- /* addColumnIfNeeded tableName columnName datatype constraint */ -}}
{{ addColumnIfNeeded "category_boards" "sort_order" "BIGINT" ""}}