package model

const (
	SqliteDBType   = "sqlite3"
	PostgresDBType = "postgres"
	MysqlDBType    = "mysql"
)
