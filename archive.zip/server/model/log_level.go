package model

import "github.com/mattermost/logr/v2"

var LvlFBTelemetry = logr.Level{
	ID:   9000,
	Name: "telemetry",
}
